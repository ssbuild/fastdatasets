# -*- coding: utf-8 -*-
# @Time:  20:08
# @Author: tk
# @File：default

import tfrecords

global_default_options = tfrecords.TFRecordOptions(tfrecords.TFRecordCompressionType.GZIP)