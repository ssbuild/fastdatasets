# -*- coding: utf-8 -*-
# @Time:  20:11
# @Author: tk
# @File：default


global_default_options = dict(enable_buffered_stream=None,
                          buffer_size= None,
                          thrift_string_size_limit= None,
                          file_decryption_properties= None,
                          check_crc= None)