# -*- coding: utf-8 -*-
# @Time:  20:11
# @Author: tk
# @File：default


global_default_options = dict( max_recursion_depth=64,
            included_fields=None,
            use_threads=None,
            ensure_native_endian=None)