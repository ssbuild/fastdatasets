# @Time    : 2022/9/18 18:05
# @Author  : tk
# @FileName: __init__.py

from tfrecords.python.io import gfile

